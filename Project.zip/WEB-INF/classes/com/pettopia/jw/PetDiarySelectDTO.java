package com.pettopia.jw;

public class PetDiarySelectDTO
{
	
	private String petName; 
	private String petId;	
	private String memberNick;	
	private String diaryId,diaryTitle;
	private int  num;
	private String larName,midName,writeDay;	
	private String diaryContent, startDate, endDate;
	private String code;
	private String diary_lar_id;
	private String diary_mid_id;
	private String place;
	private String p_open;
	
	
	//getter / setter 구성
	
	
	public String getPetName()
	{
		return petName;
	}
	public String getP_open()
	{
		return p_open;
	}
	public void setP_open(String p_open)
	{
		this.p_open = p_open;
	}
	public String getPlace()
	{
		return place;
	}
	public void setPlace(String place)
	{
		this.place = place;
	}
	public String getDiary_mid_id()
	{
		return diary_mid_id;
	}
	public void setDiary_mid_id(String diary_mid_id)
	{
		this.diary_mid_id = diary_mid_id;
	}
	public void setPetName(String petName)
	{
		this.petName = petName;
	}
	public String getPetId()
	{
		return petId;
	}
	public void setPetId(String petId)
	{
		this.petId = petId;
	}
	public String getMemberNick()
	{
		return memberNick;
	}
	public void setMemberNick(String memberNick)
	{
		this.memberNick = memberNick;
	}
	public String getDiaryId()
	{
		return diaryId;
	}
	public void setDiaryId(String diaryId)
	{
		this.diaryId = diaryId;
	}
	public String getDiaryTitle()
	{
		return diaryTitle;
	}
	public void setDiaryTitle(String diaryTitle)
	{
		this.diaryTitle = diaryTitle;
	}
	public int getNum()
	{
		return num;
	}
	public void setNum(int num)
	{
		this.num = num;
	}
	public String getLarName()
	{
		return larName;
	}
	public void setLarName(String larName)
	{
		this.larName = larName;
	}
	public String getMidName()
	{
		return midName;
	}
	public void setMidName(String midName)
	{
		this.midName = midName;
	}
	public String getWriteDay()
	{
		return writeDay;
	}
	public void setWriteDay(String writeDay)
	{
		this.writeDay = writeDay;
	}
	public String getDiaryContent()
	{
		return diaryContent;
	}
	public void setDiaryContent(String diaryContent)
	{
		this.diaryContent = diaryContent;
	}
	public String getStartDate()
	{
		return startDate;
	}
	public void setStartDate(String startDate)
	{
		this.startDate = startDate;
	}
	public String getEndDate()
	{
		return endDate;
	}
	public void setEndDate(String endDate)
	{
		this.endDate = endDate;
	}
	public String getCode()
	{
		return code;
	}
	public void setCode(String code)
	{
		this.code = code;
	}
	public String getDiary_lar_id()
	{
		return diary_lar_id;
	}
	public void setDiary_lar_id(String diary_lar_id)
	{
		this.diary_lar_id = diary_lar_id;
	}
	
	
	

	
	
}
