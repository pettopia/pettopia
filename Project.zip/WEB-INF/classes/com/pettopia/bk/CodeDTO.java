package com.pettopia.bk;

public class CodeDTO
{
	private String code, content;
	//-- (사유 등) 코드, 내용
	
	// getter / setter 
	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}
	
}
