/*=================================
  StudentDTO.java
==================================*/

package com.pettopia.mh;

public class JoinDTO
{
	
	private String member_code_seq, ip, member_reg_seq, id, nick
	, pw, ssn, addrnumber, addr1, addr3, email, phonenumber, promise_seq, agree;

	
	
	public String getMember_code_seq()
	{
		return member_code_seq;
	}

	public void setMember_code_seq(String member_code_seq)
	{
		this.member_code_seq = member_code_seq;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getMember_reg_seq()
	{
		return member_reg_seq;
	}

	public void setMember_reg_seq(String member_reg_seq)
	{
		this.member_reg_seq = member_reg_seq;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}

	public String getPw()
	{
		return pw;
	}

	public void setPw(String pw)
	{
		this.pw = pw;
	}

	public String getSsn()
	{
		return ssn;
	}

	public void setSsn(String ssn)
	{
		this.ssn = ssn;
	}

	public String getAddrnumber()
	{
		return addrnumber;
	}

	public void setAddrnumber(String addrnumber)
	{
		this.addrnumber = addrnumber;
	}

	public String getAddr1()
	{
		return addr1;
	}

	public void setAddr1(String addr1)
	{
		this.addr1 = addr1;
	}

	public String getAddr3()
	{
		return addr3;
	}

	public void setAddr3(String addr3)
	{
		this.addr3 = addr3;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getPhonenumber()
	{
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber)
	{
		this.phonenumber = phonenumber;
	}

	public String getPromise_seq()
	{
		return promise_seq;
	}

	public void setPromise_seq(String promise_seq)
	{
		this.promise_seq = promise_seq;
	}

	public String getAgree()
	{
		return agree;
	}

	public void setAgree(String agree)
	{
		this.agree = agree;
	} 

	
	
	
	
	
	
	
	
}
