/*=================================
  StudentDTO.java
==================================*/

package com.pettopia.mh;

public class DepositDTO
{
	private String care_req_seq, petname, psnick, carepay,care_agree_seq, reqdate,caredate, agreedate;
					
	private String depositprice, name, bank_seq;
	
	public String getDepositprice()
	{
		return depositprice;
	}

	public void setDepositprice(String depositprice)
	{
		this.depositprice = depositprice;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getBank_seq()
	{
		return bank_seq;
	}

	public void setBank_seq(String bank_seq)
	{
		this.bank_seq = bank_seq;
	}

	public String getCare_req_seq()
	{
		return care_req_seq;
	}

	public void setCare_req_seq(String care_req_seq)
	{
		this.care_req_seq = care_req_seq;
	}

	public String getPetname()
	{
		return petname;
	}

	public void setPetname(String petname)
	{
		this.petname = petname;
	}

	public String getPsnick()
	{
		return psnick;
	}

	public void setPsnick(String psnick)
	{
		this.psnick = psnick;
	}

	public String getCarepay()
	{
		return carepay;
	}

	public void setCarepay(String carepay)
	{
		this.carepay = carepay;
	}

	public String getCare_agree_seq()
	{
		return care_agree_seq;
	}

	public void setCare_agree_seq(String care_agree_seq)
	{
		this.care_agree_seq = care_agree_seq;
	}

	public String getReqdate()
	{
		return reqdate;
	}

	public void setReqdate(String reqdate)
	{
		this.reqdate = reqdate;
	}

	public String getCaredate()
	{
		return caredate;
	}

	public void setCaredate(String caredate)
	{
		this.caredate = caredate;
	}

	public String getAgreedate()
	{
		return agreedate;
	}

	public void setAgreedate(String agreedate)
	{
		this.agreedate = agreedate;
	}
	
	
	
	
}
