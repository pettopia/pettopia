package com.pettopia.mh;

public class MyBoardDTO
{
   private String board_seq, head_seq , head, member_code_seq,nick, title, content, reg_date, view_num, recom_num, reply;

   
   public String getReply()
   {
      return reply;
   }

   public void setReply(String reply)
   {
      this.reply = reply;
   }

   public String getNick()
   {
      return nick;
   }

   public void setNick(String nick)
   {
      this.nick = nick;
   }

   public String getHead()
   {
      return head;
   }

   public void setHead(String head)
   {
      this.head = head;
   }

   public String getBoard_seq()
   {
      return board_seq;
   }

   public void setBoard_seq(String board_seq)
   {
      this.board_seq = board_seq;
   }

   

   public String getHead_seq()
   {
      return head_seq;
   }

   public void setHead_seq(String head_seq)
   {
      this.head_seq = head_seq;
   }

   public String getMember_code_seq()
   {
      return member_code_seq;
   }

   public void setMember_code_seq(String member_code_seq)
   {
      this.member_code_seq = member_code_seq;
   }

   public String getTitle()
   {
      return title;
   }

   public void setTitle(String title)
   {
      this.title = title;
   }

   public String getContent()
   {
      return content;
   }

   public void setContent(String content)
   {
      this.content = content;
   }

   public String getReg_date()
   {
      return reg_date;
   }

   public void setReg_date(String reg_date)
   {
      this.reg_date = reg_date;
   }

   public String getView_num()
   {
      return view_num;
   }

   public void setView_num(String view_num)
   {
      this.view_num = view_num;
   }

   public String getRecom_num()
   {
      return recom_num;
   }

   public void setRecom_num(String recom_num)
   {
      this.recom_num = recom_num;
   }
   
   
   
}