/*=================================
  StudentDTO.java
==================================*/

package com.pettopia.mh;

public class MyCareDTO
{
	//주요 속성 구성
	private String member_code_seq, nick, care_req_seq, psnick, reqdate, caredate, state1, state2, state3, id, petname;

	private String breed, petsize, gender, neutral, nature;
	
	
	
	public String getBreed()
	{
		return breed;
	}

	public void setBreed(String breed)
	{
		this.breed = breed;
	}

	public String getPetsize()
	{
		return petsize;
	}

	public void setPetsize(String petsize)
	{
		this.petsize = petsize;
	}

	public String getGender()
	{
		return gender;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public String getNeutral()
	{
		return neutral;
	}

	public void setNeutral(String neutral)
	{
		this.neutral = neutral;
	}

	public String getNature()
	{
		return nature;
	}

	public void setNature(String nature)
	{
		this.nature = nature;
	}

	public String getMember_code_seq()
	{
		return member_code_seq;
	}

	public void setMember_code_seq(String member_code_seq)
	{
		this.member_code_seq = member_code_seq;
	}

	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}

	public String getCare_req_seq()
	{
		return care_req_seq;
	}

	public void setCare_req_seq(String care_req_seq)
	{
		this.care_req_seq = care_req_seq;
	}

	public String getPetname()
	{
		return petname;
	}

	public void setPetname(String petname)
	{
		this.petname = petname;
	}

	public String getPsnick()
	{
		return psnick;
	}

	public void setPsnick(String psnick)
	{
		this.psnick = psnick;
	}

	public String getReqdate()
	{
		return reqdate;
	}

	public void setReqdate(String reqdate)
	{
		this.reqdate = reqdate;
	}

	public String getCaredate()
	{
		return caredate;
	}

	public void setCaredate(String caredate)
	{
		this.caredate = caredate;
	}

	public String getState1()
	{
		return state1;
	}

	public void setState1(String state1)
	{
		this.state1 = state1;
	}

	public String getState2()
	{
		return state2;
	}

	public void setState2(String state2)
	{
		this.state2 = state2;
	}

	public String getState3()
	{
		return state3;
	}

	public void setState3(String state3)
	{
		this.state3 = state3;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	
	
	
	
}
