package com.pettopia.mh;

public class MyReplyDTO
{
	private String head, title, content, reg_date, nick, member_code_seq;

	public String getHead()
	{
		return head;
	}

	public void setHead(String head)
	{
		this.head = head;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getReg_date()
	{
		return reg_date;
	}

	public void setReg_date(String reg_date)
	{
		this.reg_date = reg_date;
	}

	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}

	public String getMember_code_seq()
	{
		return member_code_seq;
	}

	public void setMember_code_seq(String member_code_seq)
	{
		this.member_code_seq = member_code_seq;
	}
	
	
	
	
}
