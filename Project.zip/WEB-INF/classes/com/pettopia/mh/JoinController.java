/*=========================
   StudentController.java
=========================*/
package com.pettopia.mh;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class JoinController
{
	@Autowired
	private SqlSession sqlSession;

	@RequestMapping(value = "/checkjoin.action", method ={ RequestMethod.GET, RequestMethod.POST })
	public String checkjoin(Model model)
	{
		String result = null;

		result = "/WEB-INF/views/CheckJoin.jsp";

		return result;
	}

	@RequestMapping(value = "/joinform.action", method = RequestMethod.POST)
	public String joinform(Model model, HttpServletRequest request)
	{
		String result = null;
		
		String[] arr = request.getParameterValues("chk");
		
		if(arr[0] == null || arr[1] == null)
		{
			result = "redirect:main.action";
		}
		else 
		{
			model.addAttribute("arr", arr);
			result = "/WEB-INF/views/JoinForm.jsp";
		}

		return result;
	}
	
	@RequestMapping(value = "/join.action", method = RequestMethod.POST)
	public String join(Model model, MyPageDTO dto, HttpSession session)
	{
		IMyPageDAO dao = sqlSession.getMapper(IMyPageDAO.class);
		String result = null;
		
		try 
		{ 
			dao.join(dto);
			
			session.setAttribute("id", dao.login(dto));
			session.setAttribute("code", dao.searchCode(dao.login(dto)));
			session.setAttribute("nick", dao.searchNick(dao.login(dto)));

			model.addAttribute("msg", "회원가입 성공"); 
			model.addAttribute("url","/main.action");
		
		} catch (NullPointerException e) 
		{ 
			model.addAttribute("msg", "회원가입 실패");
			model.addAttribute("url", "/checkjoin.action");
		}
		
		result = "/WEB-INF/views/Alert.jsp";
		return result;
	}
	
	@RequestMapping(value = "/idajax.action", method = { RequestMethod.GET, RequestMethod.POST })
	public String idList(Model model, String idName)
	{
		IMyPageDAO dao = sqlSession.getMapper(IMyPageDAO.class);

		String result = null;

		String str = "";

		for (MyPageDTO dto : dao.idlist())
		{
			if (dto.getId().equals(idName))
			{
				str = "이미 사용중인 아이디가 존재합니다.";
				break;
			} else
			{
				str = "사용할 수 있는 아이디입니다.";
			}
		}

		model.addAttribute("result", str);

		result = "/WEB-INF/views/IdAjax.jsp";

		return result;
	}

}