/*=================================
  StudentDTO.java
==================================*/

package com.pettopia.mh;

public class BankDTO
{
	private String seq, bankname;

	public String getSeq()
	{
		return seq;
	}

	public void setSeq(String seq)
	{
		this.seq = seq;
	}

	public String getBankname()
	{
		return bankname;
	}

	public void setBankname(String bankname)
	{
		this.bankname = bankname;
	}
	
	
	
	
}
