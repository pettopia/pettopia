package com.pettopia.hj;

public class WalkFindDTO
{
	//산책검색DTO
	//인원수, 목적, 지역, 성별, 강아지크기, 연령대
	private String seq, walk_nop_seq, walk_aim_seq, region_lar_seq,larname
	   , pet_con_reg_seq, pet_size_seq, walktitle, walkdate
	   , walkplace, views,writedate, gender_op_seq, age_op_seq, region_hap,nick
	   , walk_meeting_seq;


	
	public String getWalk_meeting_seq()
	{
		return walk_meeting_seq;
	}

	public void setWalk_meeting_seq(String walk_meeting_seq)
	{
		this.walk_meeting_seq = walk_meeting_seq;
	}

	public String getLarname()
	{
		return larname;
	}

	public void setLarname(String larname)
	{
		this.larname = larname;
	}

	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}

	public String getViews()
	{
		return views;
	}

	public void setViews(String views)
	{
		this.views = views;
	}

	public String getRegion_hap()
	{
		return region_hap;
	}

	public void setRegion_hap(String region_hap)
	{
		this.region_hap = region_hap;
	}

	public String getSeq()
	{
		return seq;
	}

	public void setSeq(String seq)
	{
		this.seq = seq;
	}

	public String getWalk_nop_seq()
	{
		return walk_nop_seq;
	}

	public void setWalk_nop_seq(String walk_nop_seq)
	{
		this.walk_nop_seq = walk_nop_seq;
	}

	public String getWalk_aim_seq()
	{
		return walk_aim_seq;
	}

	public void setWalk_aim_seq(String walk_aim_seq)
	{
		this.walk_aim_seq = walk_aim_seq;
	}

	public String getRegion_lar_seq()
	{
		return region_lar_seq;
	}

	public void setRegion_lar_seq(String region_lar_seq)
	{
		this.region_lar_seq = region_lar_seq;
	}

	public String getPet_con_reg_seq()
	{
		return pet_con_reg_seq;
	}

	public void setPet_con_reg_seq(String pet_con_reg_seq)
	{
		this.pet_con_reg_seq = pet_con_reg_seq;
	}

	public String getPet_size_seq()
	{
		return pet_size_seq;
	}

	public void setPet_size_seq(String pet_size_seq)
	{
		this.pet_size_seq = pet_size_seq;
	}

	public String getWalktitle()
	{
		return walktitle;
	}

	public void setWalktitle(String walktitle)
	{
		this.walktitle = walktitle;
	}

	public String getWalkdate()
	{
		return walkdate;
	}

	public void setWalkdate(String walkdate)
	{
		this.walkdate = walkdate;
	}

	public String getWalkplace()
	{
		return walkplace;
	}

	public void setWalkplace(String walkplace)
	{
		this.walkplace = walkplace;
	}

	public String getWritedate()
	{
		return writedate;
	}

	public void setWritedate(String writedate)
	{
		this.writedate = writedate;
	}

	public String getGender_op_seq()
	{
		return gender_op_seq;
	}

	public void setGender_op_seq(String gender_op_seq)
	{
		this.gender_op_seq = gender_op_seq;
	}

	public String getAge_op_seq()
	{
		return age_op_seq;
	}

	public void setAge_op_seq(String age_op_seq)
	{
		this.age_op_seq = age_op_seq;
	}

	
	
	
}
