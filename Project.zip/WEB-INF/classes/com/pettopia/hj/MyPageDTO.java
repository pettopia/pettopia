/*=================================
  StudentDTO.java
==================================*/

package com.pettopia.hj;

public class MyPageDTO
{
	
	private String seq, member_code_seq, id, pw, ssn, nick, addrnumber
	, addr1, addr2, addr3, email, phonenumber, follower, following, filepath;

	public String getSeq()
	{
		return seq;
	}

	public void setSeq(String seq)
	{
		this.seq = seq;
	}

	public String getMember_code_seq()
	{
		return member_code_seq;
	}

	public void setMember_code_seq(String member_code_seq)
	{
		this.member_code_seq = member_code_seq;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getPw()
	{
		return pw;
	}

	public void setPw(String pw)
	{
		this.pw = pw;
	}

	public String getSsn()
	{
		return ssn;
	}

	public void setSsn(String ssn)
	{
		this.ssn = ssn;
	}

	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}

	public String getAddrnumber()
	{
		return addrnumber;
	}

	public void setAddrnumber(String addrnumber)
	{
		this.addrnumber = addrnumber;
	}

	public String getAddr1()
	{
		return addr1;
	}

	public void setAddr1(String addr1)
	{
		this.addr1 = addr1;
	}

	public String getAddr2()
	{
		return addr2;
	}

	public void setAddr2(String addr2)
	{
		this.addr2 = addr2;
	}

	public String getAddr3()
	{
		return addr3;
	}

	public void setAddr3(String addr3)
	{
		this.addr3 = addr3;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getPhonenumber()
	{
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber)
	{
		this.phonenumber = phonenumber;
	}

	public String getFollower()
	{
		return follower;
	}

	public void setFollower(String follower)
	{
		this.follower = follower;
	}

	public String getFollowing()
	{
		return following;
	}

	public void setFollowing(String follwing)
	{
		this.following = follwing;
	}

	public String getFilepath()
	{
		return filepath;
	}

	public void setFilepath(String filepath)
	{
		this.filepath = filepath;
	}
	
	
	
	
}
