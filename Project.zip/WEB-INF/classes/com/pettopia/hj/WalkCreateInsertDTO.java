package com.pettopia.hj;

public class WalkCreateInsertDTO
{
	//산책모임개설
	private String seq, walk_nop_seq, walk_aim_seq, region_mid_seq
		   , pet_con_reg_seq, pet_size_seq, walktitle, walkdate
		   , walkplace, writedate, views, gender_op_seq, age_op_seq, contents;
	
	private String code;

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getContents()
	{
		return contents;
	}

	public void setContents(String contents)
	{
		this.contents = contents;
	}

	public String getSeq()
	{
		return seq;
	}

	public void setSeq(String seq)
	{
		this.seq = seq;
	}

	public String getWalk_nop_seq()
	{
		return walk_nop_seq;
	}

	public void setWalk_nop_seq(String walk_nop_seq)
	{
		this.walk_nop_seq = walk_nop_seq;
	}

	public String getWalk_aim_seq()
	{
		return walk_aim_seq;
	}

	public void setWalk_aim_seq(String walk_aim_seq)
	{
		this.walk_aim_seq = walk_aim_seq;
	}

	public String getRegion_mid_seq()
	{
		return region_mid_seq;
	}

	public void setRegion_mid_seq(String region_mid_seq)
	{
		this.region_mid_seq = region_mid_seq;
	}

	public String getPet_con_reg_seq()
	{
		return pet_con_reg_seq;
	}

	public void setPet_con_reg_seq(String pet_con_reg_seq)
	{
		this.pet_con_reg_seq = pet_con_reg_seq;
	}

	public String getPet_size_seq()
	{
		return pet_size_seq;
	}

	public void setPet_size_seq(String pet_size_seq)
	{
		this.pet_size_seq = pet_size_seq;
	}

	public String getWalktitle()
	{
		return walktitle;
	}

	public void setWalktitle(String walktitle)
	{
		this.walktitle = walktitle;
	}

	public String getWalkdate()
	{
		return walkdate;
	}

	public void setWalkdate(String walkdate)
	{
		this.walkdate = walkdate;
	}

	public String getWalkplace()
	{
		return walkplace;
	}

	public void setWalkplace(String walkplace)
	{
		this.walkplace = walkplace;
	}

	public String getWritedate()
	{
		return writedate;
	}

	public void setWritedate(String writedate)
	{
		this.writedate = writedate;
	}

	public String getViews()
	{
		return views;
	}

	public void setViews(String views)
	{
		this.views = views;
	}

	public String getGender_op_seq()
	{
		return gender_op_seq;
	}

	public void setGender_op_seq(String gender_op_seq)
	{
		this.gender_op_seq = gender_op_seq;
	}

	public String getAge_op_seq()
	{
		return age_op_seq;
	}

	public void setAge_op_seq(String age_op_seq)
	{
		this.age_op_seq = age_op_seq;
	}
	
}
