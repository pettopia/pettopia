package com.pettopia.hj;


public interface IWalkUserProfileDAO
{
	
		//유저 프로필
		public WalkUserProfileDTO list(String walk_meeting_seq);
		
		
}
