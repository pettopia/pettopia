/*=================================
  StudentDTO.java
==================================*/

package com.pettopia.hj;

public class LoginDTO
{
	
	private String id, pw;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getPw()
	{
		return pw;
	}

	public void setPw(String pw)
	{
		this.pw = pw;
	}
	
	
	
	
	
}
