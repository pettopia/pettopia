package com.pettopia.hj;

public class WalkCreateDTO
{
	private String seq, walk_nop_seq, walk_aim_seq, region_mid_seq, pet_con_reg_seq
			,pet_size_seq, walktitle, walkdate, walkplace, writedate, views, gender_op_seq
			,age_op_seq;

	private String membercode, petname;
	
	private String larname, midname;
	
	private String region_lar_id;
	
	public String getRegion_lar_id()
	{
		return region_lar_id;
	}

	public void setRegion_lar_id(String region_lar_id)
	{
		this.region_lar_id = region_lar_id;
	}

	public String getLarname()
	{
		return larname;
	}

	public void setLarname(String larname)
	{
		this.larname = larname;
	}

	public String getMidname()
	{
		return midname;
	}

	public void setMidname(String midname)
	{
		this.midname = midname;
	}

	public String getMembercode()
	{
		return membercode;
	}

	public void setMembercode(String membercode)
	{
		this.membercode = membercode;
	}

	public String getPetname()
	{
		return petname;
	}

	public void setPetname(String petname)
	{
		this.petname = petname;
	}

	public String getSeq()
	{
		return seq; 
	}

	public void setSeq(String seq)
	{
		this.seq = seq;
	}

	public String getWalk_nop_seq()
	{
		return walk_nop_seq;
	}

	public void setWalk_nop_seq(String walk_nop_seq)
	{
		this.walk_nop_seq = walk_nop_seq;
	}

	public String getWalk_aim_seq()
	{
		return walk_aim_seq;
	}

	public void setWalk_aim_seq(String walk_aim_seq)
	{
		this.walk_aim_seq = walk_aim_seq;
	}

	public String getRegion_mid_seq()
	{
		return region_mid_seq;
	}

	public void setRegion_mid_seq(String region_mid_seq)
	{
		this.region_mid_seq = region_mid_seq;
	}

	public String getPet_con_reg_seq()
	{
		return pet_con_reg_seq;
	}

	public void setPet_con_reg_seq(String pet_con_reg_seq)
	{
		this.pet_con_reg_seq = pet_con_reg_seq;
	}

	public String getPet_size_seq()
	{
		return pet_size_seq;
	}

	public void setPet_size_seq(String pet_size_seq)
	{
		this.pet_size_seq = pet_size_seq;
	}

	public String getWalktitle()
	{
		return walktitle;
	}

	public void setWalktitle(String walktitle)
	{
		this.walktitle = walktitle;
	}

	public String getWalkdate()
	{
		return walkdate;
	}

	public void setWalkdate(String walkdate)
	{
		this.walkdate = walkdate;
	}

	public String getWalkplace()
	{
		return walkplace;
	}

	public void setWalkplace(String walkplace)
	{
		this.walkplace = walkplace;
	}

	public String getWritedate()
	{
		return writedate;
	}

	public void setWritedate(String writedate)
	{
		this.writedate = writedate;
	}

	public String getViews()
	{
		return views;
	}

	public void setViews(String views)
	{
		this.views = views;
	}

	public String getGender_op_seq()
	{
		return gender_op_seq;
	}

	public void setGender_op_seq(String gender_op_seq)
	{
		this.gender_op_seq = gender_op_seq;
	}

	public String getAge_op_seq()
	{
		return age_op_seq;
	}

	public void setAge_op_seq(String age_op_seq)
	{
		this.age_op_seq = age_op_seq;
	}
	
	

	
	
}
