package com.pettopia.hj;

public class WalkUserProfileDTO
{
	private String nick,addr1,gender,age,petname,breed,petgender,neutral,petage,ascore,seq,walk_meeting_seq;

	public String getWalk_meeting_seq()
	{
		return walk_meeting_seq;
	}

	public void setWalk_meeting_seq(String walk_meeting_seq)
	{
		this.walk_meeting_seq = walk_meeting_seq;
	}


	//getter setter
	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}

	public String getAddr1()
	{
		return addr1;
	}

	public void setAddr1(String addr1)
	{
		this.addr1 = addr1;
	}

	public String getGender()
	{
		return gender;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public String getAge()
	{
		return age;
	}

	public void setAge(String age)
	{
		this.age = age;
	}

	public String getPetname()
	{
		return petname;
	}

	public void setPetname(String petname)
	{
		this.petname = petname;
	}

	public String getBreed()
	{
		return breed;
	}

	public void setBreed(String breed)
	{
		this.breed = breed;
	}

	public String getPetgender()
	{
		return petgender;
	}

	public void setPetgender(String petgender)
	{
		this.petgender = petgender;
	}

	public String getNeutral()
	{
		return neutral;
	}

	public void setNeutral(String neutral)
	{
		this.neutral = neutral;
	}

	public String getPetage()
	{
		return petage;
	}

	public void setPetage(String petage)
	{
		this.petage = petage;
	}

	public String getAscore()
	{
		return ascore;
	}

	public void setAscore(String ascore)
	{
		this.ascore = ascore;
	}

	public String getSeq()
	{
		return seq;
	}

	public void setSeq(String seq)
	{
		this.seq = seq;
	}
	
	
}
