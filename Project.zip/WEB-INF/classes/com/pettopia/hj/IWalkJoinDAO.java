package com.pettopia.hj;

public interface IWalkJoinDAO
{
	//산책 참여 interface
	
	public int walkjoin(WalkJoinDTO dto);
	
	public String walkjoinpart(WalkJoinDTO dto);
	
}
