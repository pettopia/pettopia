package com.pettopia.hj;

public class WalkMeetingDTO
{
	private String walktitle, walkdate, walkaim, numpeople, views, sizename, larname, midname,
			walkplace, writedate, genderoption, ageoption, nick, contents, beforetitle,
			nexttitle, walk_meeting_seq;

	public String getWalk_meeting_seq()
	{
		return walk_meeting_seq;
	}

	public void setWalk_meeting_seq(String walk_meeting_seq)
	{
		this.walk_meeting_seq = walk_meeting_seq;
	}

	public String getBeforetitle()
	{
		return beforetitle;
	}

	public void setBeforetitle(String beforetitle)
	{
		this.beforetitle = beforetitle;
	}

	public String getNexttitle()
	{
		return nexttitle;
	}

	public void setNexttitle(String nexttitle)
	{
		this.nexttitle = nexttitle;
	}


	public String getContents()
	{
		return contents;
	}

	

	public void setContents(String contents)
	{
		this.contents = contents;
	}

	// getter/setter
	public String getWalktitle()
	{
		return walktitle;
	}

	public void setWalktitle(String walktitle)
	{
		this.walktitle = walktitle;
	}

	public String getWalkdate()
	{
		return walkdate;
	}

	public void setWalkdate(String walkdate)
	{
		this.walkdate = walkdate;
	}

	public String getWalkaim()
	{
		return walkaim;
	}

	public void setWalkaim(String walkaim)
	{
		this.walkaim = walkaim;
	}

	public String getNumpeople()
	{
		return numpeople;
	}

	public void setNumpeople(String numpeople)
	{
		this.numpeople = numpeople;
	}

	public String getViews()
	{
		return views;
	}

	public void setViews(String views)
	{
		this.views = views;
	}

	public String getSizename()
	{
		return sizename;
	}

	public void setSizename(String sizename)
	{
		this.sizename = sizename;
	}

	public String getLarname()
	{
		return larname;
	}

	public void setLarname(String larname)
	{
		this.larname = larname;
	}

	public String getMidname()
	{
		return midname;
	}

	public void setMidname(String midname)
	{
		this.midname = midname;
	}

	public String getWalkplace()
	{
		return walkplace;
	}

	public void setWalkplace(String walkplace)
	{
		this.walkplace = walkplace;
	}

	public String getWritedate()
	{
		return writedate;
	}

	public void setWritedate(String writedate)
	{
		this.writedate = writedate;
	}

	public String getGenderoption()
	{
		return genderoption;
	}

	public void setGenderoption(String genderoption)
	{
		this.genderoption = genderoption;
	}

	public String getAgeoption()
	{
		return ageoption;
	}

	public void setAgeoption(String ageoption)
	{
		this.ageoption = ageoption;
	}

	public String getNick()
	{
		return nick;
	}

	public void setNick(String nick)
	{
		this.nick = nick;
	}
	
	
}
